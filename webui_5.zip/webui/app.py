from flask import Flask,render_template,request,make_response
import subprocess
import os
import json
import binascii
import connect
app = Flask(__name__)

class Session:
    sessions = {}
    
    def authenticate(self, ssid, passwd):
        self.ssid = ssid
        self.passwd = passwd
        
        self.scheme = connect.SchemeWPA('wlan1', ssid, {"ssid": ssid,"psk": passwd}))
        self.scheme.save()
        
        #Check validity of ssid and password
        #if not self.wireless.connect(ssid=ssid, password=passwd):
        #    return None
        
        self.sessid = binascii.b2a_hex(os.urandom(16)).decode()
        
        Session.sessions[self.sessid] = self
        
        return self.sessid
    
    def getActiveSession(sessid):
        if sessid in Session.sessions:
            return Session.sessions[sessid]
        return False
    
@app.route("/")
def landing():
    return render_template("index.html")

@app.route("/connect", methods=["POST"])
def repeaterConf():    
    ssid = request.form['ssid']
    password = request.form['pass']
    print(f'ssid is {ssid} and password is {password}')
    
    session_id = None
    is_active = False
    ss = None
    
    if 'session_id' in request.cookies:
        print("Session already active")
        try:
            ss = Session.sessions[request.cookies['session_id']]
            session_id = ss.sessid
            is_active = True
        except KeyError:
            print("Invalid session")
    
    if session_id == None:
        ss = Session()
        session_id = ss.authenticate(ssid, password)
    
    if session_id == None:
        return "Invalid username and password"
    
    resp = make_response(render_template('usercmd.html', ssid=ss.ssid))
    if not is_active: resp.set_cookie('session_id', session_id)
    
    return resp

@app.route("/exec", methods=["POST"])
def execCmd():
    if 'session_id' in request.cookies:
        ss = Session.getActiveSession(request.cookies.get('session_id'))
        if ss:
            try:
                exec_call = subprocess.run(request.json.get('cmd'), stdout=subprocess.PIPE)
                return json.dumps({"result": "ok", "data": exec_call.stdout.decode()})
            except Exception as e:
                return json.dumps({"result": "error", "data": str(e)})
        
    return '{"result": "error"}'


if __name__=="__main__":
    app.run(debug=True)